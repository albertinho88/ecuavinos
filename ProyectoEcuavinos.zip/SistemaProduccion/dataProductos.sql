INSERT INTO tipos_producto (cod_tipo_producto, descripcion)
VALUES ('R', 'Red');

INSERT INTO tipos_producto (cod_tipo_producto, descripcion)
VALUES ('W', 'White');


INSERT INTO productos (codigo_producto, descripcion, cod_tipo_producto)
VALUES ('12765','McDonell Pinot Noir','R');

INSERT INTO productos (codigo_producto, descripcion, cod_tipo_producto)
VALUES ('12766','Mornington Pinot Noir','R');

INSERT INTO productos (codigo_producto, descripcion, cod_tipo_producto)
VALUES ('12767','Downunder Pinot Noir','R');

INSERT INTO productos (codigo_producto, descripcion, cod_tipo_producto)
VALUES ('12821','Mornington Merlot','R');

INSERT INTO productos (codigo_producto, descripcion, cod_tipo_producto)
VALUES ('14821','Downunder Merlot','R');

INSERT INTO productos (codigo_producto, descripcion, cod_tipo_producto)
VALUES ('14823','Mornington Pinot Grigio','W');

INSERT INTO productos (codigo_producto, descripcion, cod_tipo_producto)
VALUES ('14827','Downunder Pinot Grigio','W');