INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('12765','McDonell Pinot Noir','2013',600,120);
INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('12765','McDonell Pinot Noir','2012',580,110);
INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('12765','McDonell Pinot Noir','2011',510,90);

INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('12766','Mornington Pinot Noir','2013',500,110);
INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('12766','Mornington Pinot Noir','2012',550,90);

INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('14823','Mornington Pinot Grigio','2013',400,70);
INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('14823','Mornington Pinot Grigio','2012',250,65);

INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('14821','Downunder Merlot','2013',550,100);
INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('14821','Downunder Merlot','2012',400,100);

INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('12767','Downunder Pinot Noir','2013',780,80);
INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('12767','Downunder Pinot Noir','2012',690,85);

INSERT INTO historial_produccion (codigo_producto, descripcion, anio, volumen_produccion, costo_docena)
VALUES ('14827','Downunder Pinot Grigio','2013',440,70);
