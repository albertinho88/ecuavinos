INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('12766','Mornington Pinot Noir','2013',180);
INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('12766','Mornington Pinot Noir','2012',150);
INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('14823','Mornington Pinot Grigio','2013',140);
INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('14823','Mornington Pinot Grigio','2012',120);
INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('12767','Downunder Pinot Noir','2013',125);
INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('12767','Downunder Pinot Noir','2012',115);

INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('12765','McDonell Pinot Noir','2011',145);
INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('12765','McDonell Pinot Noir','2012',170);
INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('12765','McDonell Pinot Noir','2013',190);

INSERT INTO productos (producto_id, descripcion, anio, precio_por_docena)
VALUES ('14827','Downunder Pinot Grigio','2013',110);

select * from productos;