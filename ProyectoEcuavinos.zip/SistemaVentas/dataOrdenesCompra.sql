INSERT INTO ordenes_compra (codigo_orden, codigo_postal, cliente_id, fecha, direccion_entrega)
VALUES ('S135','170150','C479W','2014-02-12','Av. América E11-257');
INSERT INTO ordenes_compra_detalle (codigo_orden, producto_id, anio, cantidad, precio_por_docena, precio_total)
VALUES ('S135','12765','2013',25,190,4750);
INSERT INTO ordenes_compra_detalle (codigo_orden, producto_id, anio, cantidad, precio_por_docena, precio_total)
VALUES ('S135','14823','2012',30,120,3600);



INSERT INTO ordenes_compra (codigo_orden, codigo_postal, cliente_id, fecha, direccion_entrega)
VALUES ('S140','EC4','C128R','2014-02-15','Fleet Street');
INSERT INTO ordenes_compra_detalle (codigo_orden, producto_id, anio, cantidad, precio_por_docena, precio_total)
VALUES ('S140','12767','2013',30,125,3750);



INSERT INTO ordenes_compra (codigo_orden, codigo_postal, cliente_id, fecha, direccion_entrega)
VALUES ('S168','EC4','C479W','2014-02-16','Fleet Street');
INSERT INTO ordenes_compra_detalle (codigo_orden, producto_id, anio, cantidad, precio_por_docena, precio_total)
VALUES ('S168','12767','2012',30,115,3450);
INSERT INTO ordenes_compra_detalle (codigo_orden, producto_id, anio, cantidad, precio_por_docena, precio_total)
VALUES ('S168','14827','2013',24,110,2640);