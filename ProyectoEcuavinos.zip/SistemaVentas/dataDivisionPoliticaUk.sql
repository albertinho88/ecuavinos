insert into ciudades (ciudad_id, pais_id, nombre)
values ('81','UK','Londres');
insert into area_postal (codigo_postal, ciudad_id, descripcion)
values ('SW6','81',NULL);
insert into area_postal (codigo_postal, ciudad_id, descripcion)
values ('EC4','81',NULL);